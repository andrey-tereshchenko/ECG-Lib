from .main import create_word2vec_based_on_record

__all__ = ['create_word2vec_based_on_record']
